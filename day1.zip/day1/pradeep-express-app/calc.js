exports.message="Hello All Welcome To Custom Module";


exports.add=function(a,b){
    return "Addtion :"+(a+b);
}


exports.sub=function(a,b){
    return "Substration :"+(a-b);
}

