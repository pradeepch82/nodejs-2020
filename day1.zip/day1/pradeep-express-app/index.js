//import express module
var express=require("express");
var c=require("./calc");

var server=express();

server.get("/hello",function(request,response){
    response.send(c.message+"   "+c.add(10,20)+"   "+c.sub(200,20));
});

server.post("/hello",function(request,response){
    response.send("Hello POST");
});

server.delete("/hello",function(request,response){
    response.send("Hello Delete");
});

server.put("/hello",function(request,response){
    response.send("Hello PUT");
});

server.get("/abc*g",function(request,response){
    response.send("Hello RegEX");
});

server.all("/welcome",function(request,response){
    response.send("Welcome All  :"+request.method);
});

server.listen(1212,function(){
    console.log("Express Server lsinteing on port 1212");
});

