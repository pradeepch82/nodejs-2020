var fs=require("fs");


var data=fs.readFileSync("timersdemo.js");

console.log("Contents :"+data);

console.log("File Reading completed");
