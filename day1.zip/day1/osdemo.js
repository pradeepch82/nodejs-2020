//import the os module
var os=require("os");

console.log("Platform      :"+os.platform());
console.log("Home Dir      :"+os.homedir());
console.log("Tmp Dir       :"+os.tmpdir());
console.log("Hostname      :"+os.hostname());
console.log("Total Memory  :"+os.totalmem());
console.log("Free Memoryy  :"+os.freemem());



