
var timer=setInterval(welcome,1000);


function welcome(){
    console.log("Welcome To Timers module at Atos");
}

function clear(){
    clearInterval(timer);
}

setTimeout(clear,10000);



