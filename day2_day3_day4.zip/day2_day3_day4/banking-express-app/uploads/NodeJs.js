

var fs=require("fs");
fs.readFile("NodeJs.html",function(err,data){
	console.log("");
}
)

console.log("abc");